/*
Kendal Guizado O'riley
Module 7 project 3
CS 210
*/


#include <iostream>
#include <fstream>
#include <string>
#include <fstream>
#include <map>
using namespace std;


//function to read all files and store their frequencies 
map<string, int> readFile(string fileName) {
    ifstream myInFile;
    myInFile.open(fileName);
    map<string, int> stuff;
    string item;

    if (!myInFile.is_open()) { // checks to ensure the file opens properly
        cout << "file not found" << endl;
    } // end of if

    while (myInFile >> item) {

        if (stuff.count(item)) {
            stuff[item]++;
        } // end of if
        else {
            stuff.emplace(item, 1);
        } // end of else
    } // end of while
    return stuff;
} // End of readFile


// Function to print the frequency of all items in the input file
void printAllFrequencies(map<string, int> stuff) {
    cout << endl;
    for (auto const& item : stuff) {
        cout << item.first << " " << item.second << endl;
    }
    cout << endl;
}

// Function to print the histogram of all items in the input file
void printHistogram(map<string, int> stuff) {
    cout << endl;
    for (auto const& item : stuff) {
        cout << item.first << " ";
        for (int i = 0; i < item.second; i++) {
            cout << "*";
        }
        cout << endl;
    }
}

// Function to print the frequency of a specific item
void printFrequency(map<string, int> stuff, string item) {
    cout << endl;
    if (stuff.find(item) != stuff.end()) {
        cout << "Frequency of " << item << " is " << stuff[item] << endl;
    }
    else {
        cout << "Item not found in input file" << endl;
        cout << endl;
    }
}
// Function to validate the user input
int getInput() {
    cout << endl;
    int choice;
    while (!(cin >> choice)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. Please enter an integer: " << endl;
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    return choice;

} // End of getInput()


int main() {
    string fileName = "CS210_Project_Three_Input_File.txt";
    map<string, int> stuff = readFile(fileName);
    
    int choice;
    string item;

    do {
        cout << "Menu:\n";
        cout << "1. Search for item frequency\n";
        cout << "2. Print all item frequencies\n";
        cout << "3. Print histogram of all item frequencies\n";
        cout << "4. Exit\n";

        cout << "Enter your choice: ";
        choice = getInput();

        switch (choice) {
        case 1:
            cout << endl;
            cout << "Enter item to look for: ";
            cin >> item;
            printFrequency(stuff, item);
            break;
        case 2:
            printAllFrequencies(stuff); // class function that will print out all frequencies 
            break;
        case 3:
            printHistogram(stuff);
            break;
        case 4:
            cout << "Exiting program..." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 4);


    return 0;

}